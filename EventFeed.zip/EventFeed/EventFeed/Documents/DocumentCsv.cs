﻿using EventFeed.Models;
using PdfSharpCore.Drawing;
using PdfSharpCore.Pdf;
using Serilog;
using System;
using System.IO;
using System.Net;
using System.Text.RegularExpressions;
using EventFeed.Services;

namespace EventFeed.Documents
{
    /// <summary>
    /// DUPLICATE OF PDF to simulate extension
    /// </summary>
    public class DocumentCsv: IDocument
    {
        private readonly ILogger _logger;
        private readonly IEventConfigService _config;
        private readonly PdfDocument _document;
        private readonly PdfPage _page;
        private readonly XGraphics _gfx;
        private readonly XFont _headerFont;
        private readonly XFont _bodyFont;
        private int _currentY;
        private readonly int _currentX;
        private const string FileExtension = "csv";

        public DocumentCsv(ILogger logger, IEventConfigService config)
        {
            _logger = logger.ForContext<DocumentCsv>();
            _config = config;
            _document = new PdfDocument();
            _page = _document.AddPage();
            _gfx = XGraphics.FromPdfPage(_page);
            _headerFont = new XFont("Verdana", 18, XFontStyle.BoldItalic);
            _bodyFont = new XFont("Verdana", 12);
            _currentY = 10;
            _currentX = 10;
        }

        public void Save(EventItem eventItem)
        {
            try
            {
                SetStatusType(eventItem.Type);
                SetContent(eventItem.Content);
                _document.Save(GetFilePath(eventItem));
            }
            catch (Exception e)
            {
                _logger.Error(e.Message);
                _logger.Debug(e.StackTrace);
            }
        }

        public void Delete(EventItem eventItem)
        {
            try
            {
                string filePath = GetFilePath(eventItem);
                if (File.Exists(filePath))
                {
                    File.Delete(filePath);
                }
            }
            catch (Exception e)
            {
                _logger.Error(e.Message);
                _logger.Debug(e.StackTrace);
            }
        }

        private void SetStatusType(EventType type)
        {
            _gfx.DrawString($"Status: {type}", _headerFont, XBrushes.Black,
                new XRect(_currentX, _currentY += 20, _page.Width, _page.Height),
                XStringFormats.TopLeft);
        }

        private void SetContent(Invoice invoice)
        {
            SetHeader(invoice);
            SetBody(invoice);
        }

        private void SetHeader(Invoice invoice)
        {
            _gfx.DrawString($"{ToSpaced(nameof(invoice.InvoiceId))}: {invoice.InvoiceId}", _headerFont, XBrushes.Black,
                new XRect(_currentX, _currentY += 20, _page.Width, _page.Height),
                XStringFormats.TopLeft);

            _gfx.DrawString($"{ToSpaced(nameof(invoice.InvoiceNumber))}: {invoice.InvoiceNumber}", _headerFont, XBrushes.Black,
                new XRect(_currentX, _currentY += 20, _page.Width, _page.Height),
                XStringFormats.TopLeft);

            _gfx.DrawString($"{ToSpaced(nameof(invoice.CreatedDateUtc))}: {invoice.CreatedDateUtc}", _headerFont, XBrushes.Black,
                new XRect(_currentX, _currentY += 20, _page.Width, _page.Height),
                XStringFormats.TopLeft);

            _gfx.DrawString($"{ToSpaced(nameof(invoice.UpdatedDateUtc))}: {invoice.UpdatedDateUtc}", _headerFont, XBrushes.Black,
                new XRect(_currentX, _currentY += 20, _page.Width, _page.Height),
                XStringFormats.TopLeft);

            _gfx.DrawString($"{ToSpaced(nameof(invoice.DueDateUtc))}: {invoice.DueDateUtc}", _headerFont, XBrushes.Black,
                new XRect(_currentX, _currentY += 20, _page.Width, _page.Height),
                XStringFormats.TopLeft);

            // Add spacing before body
            _currentY += 20;
        }

        private void SetBody(Invoice content)
        {
            foreach (var lineItem in content.LineItems)
            {
                AddLineItem(lineItem);
            }
        }

        private void AddLineItem(InvoiceLineItem item)
        {
            _gfx.DrawString($"{ToSpaced(nameof(item.LineItemId))}: {item.LineItemId}", _bodyFont, XBrushes.DarkBlue,
                new XRect(_currentX, _currentY += 14, _page.Width, _page.Height),
                XStringFormats.TopLeft);
            _gfx.DrawString($"{ToSpaced(nameof(item.Description))}: {item.Description}", _bodyFont, XBrushes.DarkBlue,
                new XRect(_currentX, _currentY += 14, _page.Width, _page.Height),
                XStringFormats.TopLeft);
            _gfx.DrawString($"{ToSpaced(nameof(item.Quantity))}: {item.Quantity}", _bodyFont, XBrushes.DarkBlue,
                new XRect(_currentX, _currentY += 14, _page.Width, _page.Height),
                XStringFormats.TopLeft);
            _gfx.DrawString($"{ToSpaced(nameof(item.UnitCost))} : {item.UnitCost}", _bodyFont, XBrushes.DarkBlue,
                new XRect(_currentX, _currentY += 14, _page.Width, _page.Height),
                XStringFormats.TopLeft);
            _gfx.DrawString($"{ToSpaced(nameof(item.LineItemTotalCost))}: {item.LineItemTotalCost}", _bodyFont, XBrushes.DarkBlue,
                new XRect(_currentX, _currentY += 14, _page.Width, _page.Height),
                XStringFormats.TopLeft);

            // Add spacing before next line
            _currentY += 20;
        }

        private string GetFilePath(EventItem eventItem)
        {
            return Path.Join(_config.InvoiceDirectory, $"{eventItem.Content.InvoiceId}.{FileExtension}");
        }

        private string ToSpaced(string input)
        {
            return string.Join(" ", Regex.Split(input, @"(?<!^)(?=[A-Z])"));
        }
    }
    
}
