﻿using EventFeed.Models;

namespace EventFeed.Documents
{
    public interface IDocument
    {
        void Save(EventInvoice eventInvoice);
        void Delete(EventInvoice eventInvoice);
    }
}
