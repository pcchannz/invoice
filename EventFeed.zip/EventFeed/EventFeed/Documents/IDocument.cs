﻿using System;
using System.Collections.Generic;
using System.Text;
using EventFeed.Models;

namespace EventFeed.Documents
{
    public interface IDocument
    {
        void Save(EventItem eventItem);
        void Delete(EventItem eventItem);
    }
}
