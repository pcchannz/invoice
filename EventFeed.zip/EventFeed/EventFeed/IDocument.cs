﻿using System;
using System.Collections.Generic;
using System.Text;
using EventFeed.Models;

namespace EventFeed
{
    interface IDocument
    {
        void Save(EventItem eventItem, string filePath);
    }
}
