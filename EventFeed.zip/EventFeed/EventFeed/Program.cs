﻿using EventFeed.Services;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Serilog;
using System;
using System.IO;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace EventFeed
{
    class Program
    {
        private static ILogger _logger;
        private static string _feedUrl;
        private static IConfiguration _configuration;
        private static IHttpServices _httpClient;
        private static EventPollService _eventPollService;
        private static InvoiceService _invoiceService;

        static async Task Main(string[] args)
        {
            using IHost host = CreateHostBuilder(args).Build();
            
            _logger = host.Services.GetService<ILogger>();

            _configuration = host.Services.GetService<IConfiguration>();
            _httpClient = host.Services.GetService<IHttpServices>();
            _eventPollService = host.Services.GetService<EventPollService>();
            _invoiceService = host.Services.GetService<InvoiceService>();
            _eventPollService.EventArrived += _invoiceService.OnEventArrived;

            var cts = new CancellationTokenSource();

            while (true)
            {
                try
                {
                    await VerifyConfigurationAsync();
                    await _eventPollService.StartPollingAsync(_feedUrl, cts.Token);
                }
                catch (Exception e)
                {
                    _feedUrl = null;
                    _logger.Error(e.Message);
                    _logger.Debug(e.StackTrace);
                }
            }
        }

        private static async Task VerifyConfigurationAsync()
        {
            _logger.Information("Verifying directory...");
            _invoiceService.InvoiceDir ??= _configuration.GetValue("invoice-dir", "");
            while (!Directory.Exists(_invoiceService.InvoiceDir))
            {
                _logger.Information("Please enter a valid dir:");
                _invoiceService.InvoiceDir = Console.ReadLine();
            }
            _logger.Information("Verified directory OK: {dir}", _invoiceService.InvoiceDir);

            _feedUrl ??= _configuration.GetValue("feed-url", "");
            var status = HttpStatusCode.NotFound;
            int tryCount = 0;
            while (status != HttpStatusCode.OK)
            {
                try
                {
                    _logger.Information("Verifying feed url {feedUrl}...", _feedUrl);
                    var response = await _httpClient.GetAsync(_feedUrl);
                    tryCount++;
                    status = response.StatusCode;
                    if (status != HttpStatusCode.OK)
                    {
                        _logger.Information("Response: {body}", await response.Content.ReadAsStringAsync());
                    }

                    if (tryCount > 3)
                    {
                        throw new Exception("Unable to get OK response for more than 3 times");
                    }
                }
                catch (Exception e)
                {
                    _logger.Error(e.Message);
                    _logger.Debug(e.StackTrace);
                    _logger.Information("Please enter a valid endpoint:");
                    _feedUrl = Console.ReadLine();
                    tryCount = 0;
                }
            }
            _logger.Information("Verified feed url OK: {url}", _feedUrl);
        }

        static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureServices(collection =>
                {
                    collection.AddSingleton(s =>
                    {
                        Log.Logger = new LoggerConfiguration().ReadFrom.Configuration(s.GetService<IConfiguration>())
                            .CreateLogger();
                        return Log.Logger;
                    });
                    collection.AddSingleton<IHttpServices, HttpService>();
                    collection.AddSingleton<EventPollService>();
                    collection.AddSingleton<InvoiceService>();
                });
            
    }
}
