﻿using System;
using EventFeed.Services;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Serilog;
using System.Threading;
using System.Threading.Tasks;
using EventFeed.Documents;

namespace EventFeed
{
    class Program
    {
        static async Task Main(string[] args)
        {
            using IHost host = CreateHostBuilder(args).Build();
            var cts = new CancellationTokenSource();
            while (true)
            {
                try
                {
                    await host.Services.GetRequiredService<IEventConfigService>().VerifyConfigurationAsync(cts.Token);
                    await host.Services.GetRequiredService<IPollService>().StartPollingAsync(cts.Token);
                }
                catch
                {
                    host.Services.GetRequiredService<ILogger>().Information("Restarting app...");
                }
            }
        }

        static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureServices(collection =>
                {
                    collection.AddSingleton(s =>
                    {
                        Log.Logger = new LoggerConfiguration().ReadFrom.Configuration(s.GetService<IConfiguration>())
                            .CreateLogger();
                        return Log.Logger;
                    });
                    collection.AddSingleton<IHttpServices, HttpService>();
                    collection.AddSingleton<IPollService, EventPollService>();
                    collection.AddSingleton<IInvoiceService, InvoiceService>();
                    collection.AddSingleton<IEventConfigService, EventConfigService>();
                    collection.AddTransient<IDocument, DocumentPdf>();

                    // Generate different type of document by adding another class that implement IDocument
                    collection.AddTransient<IDocument, DocumentCsv>();
                });
    }
}
