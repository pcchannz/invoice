﻿using EventFeed.Models;
using PdfSharpCore.Drawing;
using PdfSharpCore.Pdf;
using System;
using System.Text.RegularExpressions;

namespace EventFeed
{
    public class DocumentPdf: IDocument
    {
        private readonly PdfDocument _document;
        private readonly PdfPage _page;
        private readonly XGraphics _gfx;
        private readonly XFont _headerFont;
        private readonly XFont _bodyFont;
        private int _currentY;
        private readonly int _currentX;


        public DocumentPdf()
        {
            _document = new PdfDocument();
            _page = _document.AddPage();
            _gfx = XGraphics.FromPdfPage(_page);
            _headerFont = new XFont("Verdana", 18, XFontStyle.BoldItalic);
            _bodyFont = new XFont("Verdana", 12);
            _currentY = 10;
            _currentX = 10;
        }

        public void Save(EventItem eventItem, string filePath)
        {
            try
            {
                SetStatus(eventItem.Type);

                SetHeader(eventItem.Content);

                foreach (var lineItem in eventItem.Content.LineItems)
                {
                    AddLineItem(lineItem);
                }
                _document.Save(filePath);

                var operation = eventItem.Type switch
                {
                    EventType.Invoice_Deleted => "deleted",
                    EventType.Invoice_Created => "created",
                    EventType.Invoice_Updated => "updated",
                    _ => "unknown"
                };
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
            
        }

        void SetStatus(EventType type)
        {
            _gfx.DrawString($"Status: {type}", _headerFont, XBrushes.Black,
                new XRect(_currentX, _currentY += 20, _page.Width, _page.Height),
                XStringFormats.TopLeft);
        }

        void SetHeader(Invoice invoice)
        {
            _gfx.DrawString($"{ToSpaced(nameof(invoice.InvoiceId))}: {invoice.InvoiceId}", _headerFont, XBrushes.Black,
                new XRect(_currentX, _currentY += 20, _page.Width, _page.Height),
                XStringFormats.TopLeft);

            _gfx.DrawString($"{ToSpaced(nameof(invoice.InvoiceNumber))}: {invoice.InvoiceNumber}", _headerFont, XBrushes.Black,
                new XRect(_currentX, _currentY += 20, _page.Width, _page.Height),
                XStringFormats.TopLeft);

            _gfx.DrawString($"{ToSpaced(nameof(invoice.CreatedDateUtc))}: {invoice.CreatedDateUtc}", _headerFont, XBrushes.Black,
                new XRect(_currentX, _currentY += 20, _page.Width, _page.Height),
                XStringFormats.TopLeft);

            _gfx.DrawString($"{ToSpaced(nameof(invoice.UpdatedDateUtc))}: {invoice.UpdatedDateUtc}", _headerFont, XBrushes.Black,
                new XRect(_currentX, _currentY += 20, _page.Width, _page.Height),
                XStringFormats.TopLeft);

            _gfx.DrawString($"{ToSpaced(nameof(invoice.DueDateUtc))}: {invoice.DueDateUtc}", _headerFont, XBrushes.Black,
                new XRect(_currentX, _currentY += 20, _page.Width, _page.Height),
                XStringFormats.TopLeft);

            // Add spacing before body
            _currentY += 20;
        }

        void AddLineItem(InvoiceLineItem item)
        {
            _gfx.DrawString($"{ToSpaced(nameof(item.LineItemId))}: {item.LineItemId}", _bodyFont, XBrushes.DarkBlue,
                new XRect(_currentX, _currentY += 14, _page.Width, _page.Height),
                XStringFormats.TopLeft);
            _gfx.DrawString($"{ToSpaced(nameof(item.Description))}: {item.Description}", _bodyFont, XBrushes.DarkBlue,
                new XRect(_currentX, _currentY += 14, _page.Width, _page.Height),
                XStringFormats.TopLeft);
            _gfx.DrawString($"{ToSpaced(nameof(item.Quantity))}: {item.Quantity}", _bodyFont, XBrushes.DarkBlue,
                new XRect(_currentX, _currentY += 14, _page.Width, _page.Height),
                XStringFormats.TopLeft);
            _gfx.DrawString($"{ToSpaced(nameof(item.UnitCost))} : {item.UnitCost}", _bodyFont, XBrushes.DarkBlue,
                new XRect(_currentX, _currentY += 14, _page.Width, _page.Height),
                XStringFormats.TopLeft);
            _gfx.DrawString($"{ToSpaced(nameof(item.LineItemTotalCost))}: {item.LineItemTotalCost}", _bodyFont, XBrushes.DarkBlue,
                new XRect(_currentX, _currentY += 14, _page.Width, _page.Height),
                XStringFormats.TopLeft);

            // Add spacing before next line
            _currentY += 20;
        }

        string ToSpaced(string input)
        {
            return string.Join(" ", Regex.Split(input, @"(?<!^)(?=[A-Z])"));
        }
    }
    
}
