﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventFeed.Models
{
    public class Configuration
    {
        public Configuration()
        {
            PageSize = 10;
            AfterEventId = 0;
            MaxPageSize = 500;
            PollingIntervalInSeconds = 30;
        }

        public string FeedUrl { get; set; }
        public string InvoiceDir { get; set; }
        public int PageSize { get; set; }
        public int AfterEventId { get; set; }
        public int MaxPageSize { get; set; }
        public int PollingIntervalInSeconds { get; set; }
    }
}
