﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;
using System.Text.Json.Serialization;

namespace EventFeed.Models
{
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum EventType
    {
        Invoice_Created, Invoice_Updated, Invoice_Deleted
    }
}
