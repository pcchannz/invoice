﻿namespace EventFeed.Models
{
    public class InvoiceLineItem
    {
        public string LineItemId { get; set; }
        public string Description { get; set; }
        public int Quantity { get; set; }
        public float UnitCost { get; set; }
        public float LineItemTotalCost { get; set; }
    }
}
