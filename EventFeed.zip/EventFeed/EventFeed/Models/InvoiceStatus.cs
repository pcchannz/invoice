﻿using System.Text.Json.Serialization;

namespace EventFeed.Models
{
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum InvoiceStatus
    {
        Draft,
        Sent,
        Paid,
        Deleted
    }
}
