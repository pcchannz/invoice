﻿using System;
using EventFeed.Models;

namespace EventFeed.Models
{
    public class EventArrivedArgs : EventArgs
    {
        public EventResponse Response { get; set; }
    }
}