﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EventFeed.Models
{
    public class EventResponse
    {
        public ICollection<EventItem> Items { get; set; }
    }
}
