﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EventFeed.Models
{
    public class EventResponse : EventArgs
    {
        public ICollection<EventItem> Items { get; set; }
    }
}
