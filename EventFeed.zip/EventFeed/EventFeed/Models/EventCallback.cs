﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace EventFeed.Models
{
    public class EventCallback
    {
        public Configuration Configuration;
        public CancellationToken CancellationToken;
    }
}
