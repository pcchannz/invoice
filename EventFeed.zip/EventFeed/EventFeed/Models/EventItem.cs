﻿using System;

namespace EventFeed.Models
{
    public class EventItem
    {
        public int Id { get; set; }
        public EventType Type { get; set; }
        public Invoice Content { get; set; }
        public DateTimeOffset CreatedDateUtc { get; set; }
    }
}
