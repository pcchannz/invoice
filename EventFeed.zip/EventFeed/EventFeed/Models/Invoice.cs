﻿using System;
using System.Collections.Generic;

namespace EventFeed.Models
{
    public class Invoice
    {
        public string InvoiceId { get; set; }
        public string InvoiceNumber { get; set; }
        public ICollection<InvoiceLineItem> LineItems { get; set; }
        public InvoiceStatus Status { get; set; }
        public DateTimeOffset DueDateUtc { get; set; }
        public DateTimeOffset CreatedDateUtc { get; set; }
        public DateTimeOffset UpdatedDateUtc { get; set; }
    }
}
