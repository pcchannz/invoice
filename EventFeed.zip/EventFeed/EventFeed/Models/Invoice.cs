﻿using System;
using System.Collections.Generic;
using EventFeed.Types;

namespace EventFeed.Models
{
    public class Invoice
    {
        public string InvoiceId { get; set; }
        public string InvoiceNumber { get; set; }
        public ICollection<InvoiceLineItem> LineItems { get; set; }
        public InvoiceType Status { get; set; }
        public DateTimeOffset DueDateUtc { get; set; }
        public DateTimeOffset CreatedDateUtc { get; set; }
        public DateTimeOffset UpdatedDateUtc { get; set; }
    }
}
