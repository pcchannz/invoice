﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EventFeed.Models
{
    public class EventInvoices : EventArgs
    {
        public ICollection<EventInvoice> Items { get; set; }
    }
}
