﻿using EventFeed.Models;
using Microsoft.Extensions.Configuration;
using Serilog;
using System;
using System.IO;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace EventFeed.Services
{
    public class EventConfigService: EventConfiguration, IEventConfigService
    {
        private readonly ILogger _logger;
        private readonly IHttpServices _httpServices;

        public EventConfigService(ILogger logger, IConfiguration configuration, IHttpServices httpServices)
        {
            _logger = logger;
            _httpServices = httpServices;
            AfterEventId = configuration.GetValue("AfterEventId", 0);
            PageSize = Math.Min(configuration.GetValue("PageSize", 10), configuration.GetValue("MaxPageSize", 500));
            PollingInterval = configuration.GetValue("PollingIntervalInSeconds", 30);
            FeedUrl = configuration.GetValue("feed-url", "");
            InvoiceDirectory = configuration.GetValue("invoice-dir", "");
        }

        public Task VerifyConfigurationAsync(CancellationToken cancellationToken)
        {
            VerifyDirectory();
            return VerifyFeedUrlAsync(cancellationToken);
        }

        private void VerifyDirectory()
        {
            PromptInvoiceDirectoryIfNotValid();
            _logger.Information("Verified directory OK: {dir}", InvoiceDirectory);

        }

        private void PromptInvoiceDirectoryIfNotValid()
        {
            _logger.Information("Verifying directory {dir}...", InvoiceDirectory);
            while (!Directory.Exists(InvoiceDirectory))
            {
                _logger.Information("Please enter a valid directory:");
                InvoiceDirectory = Console.ReadLine();
                PromptInvoiceDirectoryIfNotValid();
            }
        }

        private async Task VerifyFeedUrlAsync(CancellationToken cancellationToken)
        {
            await PromptFeedUrlIfNotValidAsync(cancellationToken);
            _logger.Information("Verified feed url OK: {url}", FeedUrl);
        }

        private async Task PromptFeedUrlIfNotValidAsync(CancellationToken cancellationToken)
        {
            _logger.Information("Verifying feed url {feedUrl}...", FeedUrl);
            while (await GetFeedStatusCodeAsync(cancellationToken) != HttpStatusCode.OK)
            {
                _logger.Information("Please enter a valid feed url:");
                FeedUrl = Console.ReadLine();
                await PromptFeedUrlIfNotValidAsync(cancellationToken);
            }
        }

        private async Task<HttpStatusCode> GetFeedStatusCodeAsync(CancellationToken cancellationToken)
        {
            try
            {
                var response = await _httpServices.GetAsync(FeedUrl, cancellationToken);
                return response.StatusCode;

            }
            catch (Exception e)
            {
                _logger.Error(e.Message);
                _logger.Debug(e.StackTrace);
                return HttpStatusCode.BadRequest;
            }
        }
    }
}
