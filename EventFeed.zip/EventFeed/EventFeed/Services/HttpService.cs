﻿using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace EventFeed.Services
{
    public class HttpService : IHttpServices
    {
        private readonly HttpClient _client = new HttpClient();

        public Task<HttpResponseMessage> GetAsync(string url)
        {
            return _client.GetAsync(url);
        }

        public Task<string> GetStringAsync(string url)
        {
            return _client.GetStringAsync(url);
        }

        public Task<HttpResponseMessage> GetAsync(string url, CancellationToken token)
        {
            return _client.GetAsync(url, token);
        }

        public Task<string> GetStringAsync(string url, CancellationToken token)
        {
            return _client.GetStringAsync(url, token);
        }
    }
}
