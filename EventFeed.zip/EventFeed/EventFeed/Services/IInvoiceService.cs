﻿using EventFeed.Models;

namespace EventFeed.Services
{
    public interface IInvoiceService
    {
        void OnEventResponse(object sender, EventInvoices response);
    }
}
