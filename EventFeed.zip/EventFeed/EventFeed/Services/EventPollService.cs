﻿using EventFeed.Models;
using Serilog;
using System;
using System.Linq;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using System.Web;

namespace EventFeed.Services
{
    public class EventPollService: IPollService
    {
        private readonly IHttpServices _httpClient;
        private readonly IEventConfigService _config;
        public event EventHandler<EventInvoices> OnEventResponse;
        private readonly JsonSerializerOptions _jsonSerializerOptions = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
        private readonly ILogger _logger;

        public EventPollService(ILogger logger,
            IHttpServices client,
            IEventConfigService config,
            IInvoiceService invoiceService)
        {
            _logger = logger.ForContext<EventPollService>();
            _httpClient = client;
            _config = config;

            // Setup events
            OnEventResponse += invoiceService.OnEventResponse;
        }

        public async Task StartPollingAsync(CancellationToken cancellationToken)
        {
            _logger.Information($"Polling service started with interval {_config.PollingInterval}");
            await RunWithAllowableErrorAsync(cancellationToken);
            _logger.Information("Polling service stopped");
        }

        private async Task RunWithAllowableErrorAsync(CancellationToken cancellationToken)
        {
            while (!cancellationToken.IsCancellationRequested)
            {
                try
                {
                    EventInvoices eventResponse = await GetEventResponse(cancellationToken);
                    await DelayPoll(eventResponse, cancellationToken);
                }
                catch (TaskCanceledException)
                {
                    _logger.Information("Polling task cancelled");
                }
            }
        }

        private async Task DelayPoll(EventInvoices response, CancellationToken cancellationToken)
        {
            if (!IsBatchFull(response))
            {
                await Task.Delay(1000 * _config.PollingInterval, cancellationToken);
            }
        }

        private bool IsBatchFull(EventInvoices response)
        {
            if (response.Items.Count != _config.PageSize) return false;
            _logger.Debug("Poll before interval as batch size is full");
            _config.PageSize = response.Items.Last().Id;
            return true;
        }

        private async Task<EventInvoices> GetEventResponse(CancellationToken cancellationToken)
        {
            try
            {
                string constructedUrl = GetConstructedUrl();
                _logger.Information($"Downloading data via {constructedUrl}");
                var data = await _httpClient.GetStringAsync(constructedUrl, cancellationToken);
                var response = JsonSerializer.Deserialize<EventInvoices>(data, _jsonSerializerOptions);
                OnEventResponse?.Invoke(this, response);
                return response;
            }
            catch (Exception e)
            {
                _logger.Error(e.Message);
                _logger.Debug(e.StackTrace);
                throw;
            }
        }

        private string GetConstructedUrl()
        {
            var uriBuilder = new UriBuilder(_config.FeedUrl);
            var query = HttpUtility.ParseQueryString(uriBuilder.Query);
            query["pageSize"] = _config.PageSize.ToString();
            query["afterEventId"] = _config.AfterEventId.ToString();
            uriBuilder.Query = query.ToString();
            return uriBuilder.ToString();
        }
    }
}
