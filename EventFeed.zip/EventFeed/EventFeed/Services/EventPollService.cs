﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using EventFeed.Models;
using Microsoft.Extensions.Configuration;
using Serilog;

namespace EventFeed.Services
{
    public class EventPollService
    {
        private static readonly SemaphoreSlim RefreshLock = new SemaphoreSlim(1, 1);
        private readonly IHttpServices _httpClient;
        public event EventHandler<EventArrivedArgs> EventArrived;
        private readonly JsonSerializerOptions _jsonSerializerOptions = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
        private readonly ILogger _logger;
        private readonly IConfiguration _config;
        private int _afterEventId;
        private readonly int _pageSize;
        private int _consecutiveErrorCounts;
        public EventPollService(ILogger logger, IConfiguration config, IHttpServices client)
        {
            _logger = logger.ForContext<EventPollService>();
            _config = config;
            _httpClient = client;
            _afterEventId = config.GetValue("AfterEventId", 0);
            _pageSize = Math.Min(_config.GetValue("PageSize", 10), _config.GetValue("MaxPageSize", 500));
            _consecutiveErrorCounts = 0;
        }

        public async Task StartPollingAsync(string feedUrl, CancellationToken token)
        {
            _consecutiveErrorCounts = 0;
            _logger.Information("Polling service running.");
            var pollingInterval = _config.GetValue("PollingIntervalInSeconds", 30);
            _logger.Information("Polling interval: {interval} seconds", pollingInterval);
            try
            {
                while (_consecutiveErrorCounts < 3 && !token.IsCancellationRequested)
                {
                    bool isBatchMaxed = await FetchDataAsync(feedUrl, token);
                    if (!isBatchMaxed)
                    {
                        await Task.Delay(1000 * pollingInterval, token);
                    }
                }

            }
            catch (TaskCanceledException)
            {
                return;
            }

            if (token.IsCancellationRequested)
            {
                return;
            }

            throw new Exception("Failed 3 consecutive requests");
        }

        private async Task<bool> FetchDataAsync(string feedUrl, CancellationToken token)
        {
            var eventArgs = new EventArrivedArgs();
            try
            {
                string constructedUrl = GetConstructedUrl(feedUrl);
                _logger.Information($"Downloading data via {constructedUrl}");
                var data = await _httpClient.GetStringAsync(constructedUrl, token);
                EventHandler<EventArrivedArgs> handler = EventArrived;
                eventArgs.Response = JsonSerializer.Deserialize<EventResponse>(data, _jsonSerializerOptions);
                handler?.Invoke(this, eventArgs);
                _consecutiveErrorCounts = 0;
                if (eventArgs.Response.Items.Count == _pageSize)
                {
                    _logger.Debug("Poll before interval as batch size is full");
                    _afterEventId = eventArgs.Response.Items.Last().Id;
                    return true;
                }
            }
            catch (JsonException e)
            {
                _logger.Error("Error deserializing json: {message}", e.Message);
                _logger.Debug(e.StackTrace);
                _consecutiveErrorCounts++;
                return true;
            }
            catch (Exception e)
            {
                _logger.Error(e.Message);
                _logger.Debug(e.StackTrace);
                _consecutiveErrorCounts++;
                return true;
            }
            return false;
        }

        private string GetConstructedUrl(string feedUrl)
        {
            var uriBuilder = new UriBuilder(feedUrl);
            var query = HttpUtility.ParseQueryString(uriBuilder.Query);
            query["pageSize"] = _pageSize.ToString();
            query["afterEventId"] = _afterEventId.ToString();
            uriBuilder.Query = query.ToString();
            return uriBuilder.ToString();
        }
    }
}
