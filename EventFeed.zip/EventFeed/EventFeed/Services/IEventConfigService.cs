﻿using System.Threading;
using EventFeed.Models;
using System.Threading.Tasks;

namespace EventFeed.Services
{
    public interface IEventConfigService: IEventConfiguration
    {
        Task VerifyConfigurationAsync(CancellationToken cancellationToken);
    }
}
