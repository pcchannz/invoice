﻿using System.Threading;
using EventFeed.Models;
using System.Threading.Tasks;
using EventFeed.Configurations;

namespace EventFeed.Services
{
    public interface IEventConfigService: IEventConfiguration
    {
        Task VerifyConfigurationAsync(CancellationToken cancellationToken);
    }
}
