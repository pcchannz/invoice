﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using EventFeed.Models;
using Microsoft.Extensions.Configuration;
using Serilog;

namespace EventFeed.Services
{
    public class InvoiceService
    {
        private readonly ILogger _logger;
        public string InvoiceDir { get; set; }

        public InvoiceService(ILogger logger)
        {
            _logger = logger.ForContext<InvoiceService>();
        }

        public void OnEventArrived(object sender, EventArrivedArgs e)
        {
            _logger.Information($"Event received");

            if (e.Response?.Items != null)
            {
                _logger.Information("Batch size: {size}", e.Response.Items.Count);
                foreach (var eventItem in e.Response.Items)
                {
                    string filePath = $"{InvoiceDir}\\{eventItem.Content.InvoiceId}.pdf";
                    switch (eventItem.Type)
                    {
                        case EventType.Invoice_Created:
                            IDocument createInvoice = new DocumentPdf();
                            createInvoice.Save(eventItem, filePath);
                            _logger.Debug("Document {id} is created", eventItem.Content.InvoiceId);
                            break;
                        case EventType.Invoice_Updated:
                            IDocument updateInvoice = new DocumentPdf();
                            updateInvoice.Save(eventItem, filePath);
                            _logger.Debug("Document {id} is updated", eventItem.Content.InvoiceId);
                            break;
                        case EventType.Invoice_Deleted:
                            if (File.Exists(filePath))
                            {
                                File.Delete(filePath);
                                _logger.Debug("Document {id} is deleted", eventItem.Content.InvoiceId);
                            }
                            else
                            {
                                _logger.Debug("Skipped. Unable to find document id for deletion.", eventItem.Content.InvoiceId);
                            }
                            break;
                    }
                }
            }
            else
            {
                _logger.Information("Empty response object");
            }

            _logger.Information($"Event completed at {DateTime.Now}");
        }
    }
}
