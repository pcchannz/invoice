﻿using EventFeed.Models;
using Serilog;
using System;
using EventFeed.Documents;
using Microsoft.Extensions.DependencyInjection;

namespace EventFeed.Services
{
    public class InvoiceService: IInvoiceService
    {
        private readonly IServiceProvider _serviceProvider;
        private readonly ILogger _logger;

        public InvoiceService(ILogger logger, IServiceProvider serviceProvider)
        {
            _logger = logger.ForContext<InvoiceService>();
            _serviceProvider = serviceProvider;
        }

        public void OnEventResponse(object sender, EventResponse response)
        {
            _logger.Information($"Event received");
            ProcessEventResponse(response);
            _logger.Information($"Event completed at {DateTime.Now}");
        }

        private void ProcessEventResponse(EventResponse response)
        {
            if (IsResponseEmpty(response)) return;
            _logger.Information("Batch size: {size}", response.Items.Count);
            foreach (var eventItem in response.Items)
            {
                ProcessEventItem(eventItem);
            }
        }

        private bool IsResponseEmpty(EventResponse response)
        {
            if (response.Items != null) return false;
            _logger.Information("Empty response object");
            return true;
        }

        private void ProcessEventItem(EventItem eventItem)
        {
            switch (eventItem.Type)
            {
                case EventType.Invoice_Created:
                case EventType.Invoice_Updated:
                    UpsertFiles(eventItem);
                    break;
                case EventType.Invoice_Deleted:
                    DeleteFiles(eventItem);
                    break;
            }
            _logger.Information("Document {id} is {eventType}", eventItem.Content.InvoiceId, eventItem.Type);
        }

        private void UpsertFiles(EventItem eventItem)
        {
            var documents = _serviceProvider.GetServices<IDocument>();
            foreach (var document in documents)
            {
                document.Save(eventItem);
            }
        }

        private void DeleteFiles(EventItem eventItem)
        {
            var documents = _serviceProvider.GetServices<IDocument>();
            foreach (var document in documents)
            {
                document.Delete(eventItem);
            }
        }
    }
}
