﻿using EventFeed.Models;
using Serilog;
using System;
using EventFeed.Documents;
using EventFeed.Types;
using Microsoft.Extensions.DependencyInjection;

namespace EventFeed.Services
{
    public class InvoiceService: IInvoiceService
    {
        private readonly IServiceProvider _serviceProvider;
        private readonly ILogger _logger;

        public InvoiceService(ILogger logger, IServiceProvider serviceProvider)
        {
            _logger = logger.ForContext<InvoiceService>();
            _serviceProvider = serviceProvider;
        }

        public void OnEventResponse(object sender, EventInvoices response)
        {
            _logger.Information($"Event received");
            ProcessEventResponse(response);
            _logger.Information($"Event completed at {DateTime.Now}");
        }

        private void ProcessEventResponse(EventInvoices response)
        {
            if (IsResponseEmpty(response)) return;
            _logger.Information("Batch size: {size}", response.Items.Count);
            foreach (var EventInvoice in response.Items)
            {
                ProcessEventInvoice(EventInvoice);
            }
        }

        private bool IsResponseEmpty(EventInvoices response)
        {
            if (response.Items != null) return false;
            _logger.Information("Empty response object");
            return true;
        }

        private void ProcessEventInvoice(EventInvoice EventInvoice)
        {
            switch (EventInvoice.Type)
            {
                case EventType.Invoice_Created:
                case EventType.Invoice_Updated:
                    UpsertFiles(EventInvoice);
                    break;
                case EventType.Invoice_Deleted:
                    DeleteFiles(EventInvoice);
                    break;
            }
            _logger.Information("Document {id} is {eventType}", EventInvoice.Content.InvoiceId, EventInvoice.Type);
        }

        private void UpsertFiles(EventInvoice EventInvoice)
        {
            var documents = _serviceProvider.GetServices<IDocument>();
            foreach (var document in documents)
            {
                document.Save(EventInvoice);
            }
        }

        private void DeleteFiles(EventInvoice EventInvoice)
        {
            var documents = _serviceProvider.GetServices<IDocument>();
            foreach (var document in documents)
            {
                document.Delete(EventInvoice);
            }
        }
    }
}
