﻿using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace EventFeed
{
    public interface IHttpServices
    {
        Task<HttpResponseMessage> GetAsync(string url);
        Task<string> GetStringAsync(string url);
        Task<HttpResponseMessage> GetAsync(string url, CancellationToken token);
        Task<string> GetStringAsync(string url, CancellationToken token);
    }
}
