﻿using System.Threading;
using System.Threading.Tasks;

namespace EventFeed.Services
{
    public interface IPollService
    {
        Task StartPollingAsync(CancellationToken cancellationToken);
    }
}
