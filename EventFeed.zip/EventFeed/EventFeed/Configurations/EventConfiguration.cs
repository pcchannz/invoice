﻿namespace EventFeed.Configurations
{
    public class EventConfiguration: IEventConfiguration
    {
        public string FeedUrl { get; set; }
        public string InvoiceDirectory { get; set; }
        public int PageSize { get; set; }
        public int AfterEventId { get; set; }
        public int PollingInterval { get; set; }
    }
}
