﻿using System.Text.Json.Serialization;

namespace EventFeed.Types
{
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum InvoiceType
    {
        Draft,
        Sent,
        Paid,
        Deleted
    }
}
