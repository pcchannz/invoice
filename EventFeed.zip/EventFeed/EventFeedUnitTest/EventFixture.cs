﻿using Microsoft.Extensions.Configuration;
using System.IO;
using System.Text.Json;
using System.Threading.Tasks;
using EventFeed.Models;

namespace EventFeedUnitTest
{
    public class EventFixture
    {
        private readonly JsonSerializerOptions _jsonSerializerOptions = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
        public IConfiguration GetConfiguration()
        {
            var configuration = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.test.json")
                .Build();
            return configuration;
        }

        public Task<string> Get100EventResponseAsync()
        {
            return File.ReadAllTextAsync("data/events100.json");
        }

        public EventResponse Get100EventResponse()
        {
            return JsonSerializer.Deserialize<EventResponse>(Get100EventResponseAsync().Result, _jsonSerializerOptions);
        }

        public Task<string> Get10EventResponseAsync()
        {
            return File.ReadAllTextAsync("data/events10.json");
        }

        public EventResponse Get10EventResponse()
        {
            return JsonSerializer.Deserialize<EventResponse>(Get10EventResponseAsync().Result, _jsonSerializerOptions);
        }

        public Task<string> Get5EventResponseAsync()
        {
            return File.ReadAllTextAsync("data/events5.json");
        }

        public EventResponse Get5EventResponse()
        {
            return JsonSerializer.Deserialize<EventResponse>(Get5EventResponseAsync().Result, _jsonSerializerOptions);
        }
    }
}
