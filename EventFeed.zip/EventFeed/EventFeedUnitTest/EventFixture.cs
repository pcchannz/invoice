﻿using System;
using Microsoft.Extensions.Configuration;
using System.IO;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using EventFeed;
using EventFeed.Documents;
using EventFeed.Models;
using EventFeed.Services;
using Microsoft.Extensions.DependencyInjection;
using Serilog;
using Moq;

namespace EventFeedUnitTest
{
    public class EventFixture: IDisposable
    {
        private readonly string _invoiceDirectory;
        public EventFixture()
        {
            _invoiceDirectory = Path.Join(Path.GetTempPath(), Guid.NewGuid().ToString());
            if (!Directory.Exists(_invoiceDirectory)) Directory.CreateDirectory(_invoiceDirectory);
        }

        private readonly JsonSerializerOptions _jsonSerializerOptions = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };

        public IServiceProvider GetServiceProvider()
        {
            IServiceCollection collection = new ServiceCollection();
            collection.AddSingleton<IHttpServices, HttpService>();
            collection.AddSingleton<IPollService, EventPollService>();
            collection.AddSingleton<IInvoiceService, InvoiceService>();
            collection.AddSingleton(s => GetConfigurationService());
            collection.AddSingleton<CancellationTokenSource>();
            collection.AddSingleton<ILogger>(s => Mock.Of<ILogger>());
            collection.AddTransient<IDocument, DocumentPdf>();
            collection.AddTransient<IDocument, DocumentCsv>();
            ServiceProvider provider = collection.BuildServiceProvider();
            return provider;
        }

        public IEventConfigService GetConfigurationService()
        {

            var configService =
                new EventConfigService(Mock.Of<ILogger>(), GetConfiguration(), Mock.Of<IHttpServices>())
                {
                    InvoiceDirectory = _invoiceDirectory, 
                    FeedUrl = "http://google.com"
                };
            return configService;
        }

        public static IConfiguration GetConfiguration()
        {
            var configuration = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.test.json")
                .Build();
            return configuration;
        }

        public static Task<string> Get100EventInvoicesAsync()
        {
            return File.ReadAllTextAsync("data/events100.json");
        }

        public EventInvoices Get100EventInvoices()
        {
            return JsonSerializer.Deserialize<EventInvoices>(Get100EventInvoicesAsync().Result, _jsonSerializerOptions);
        }

        public static Task<string> Get10EventInvoicesAsync()
        {
            return File.ReadAllTextAsync("data/events10.json");
        }

        public EventInvoices Get10EventInvoices()
        {
            return JsonSerializer.Deserialize<EventInvoices>(Get10EventInvoicesAsync().Result, _jsonSerializerOptions);
        }

        public static Task<string> Get5EventInvoicesAsync()
        {
            return File.ReadAllTextAsync("data/events5.json");
        }

        public EventInvoices Get5EventResponse()
        {
            return JsonSerializer.Deserialize<EventInvoices>(Get5EventInvoicesAsync().Result, _jsonSerializerOptions);
        }

        public void Dispose()
        {
            if (Directory.Exists(_invoiceDirectory)) { Directory.Delete(_invoiceDirectory, true); }
            GC.SuppressFinalize(this);
        }
    }
}
