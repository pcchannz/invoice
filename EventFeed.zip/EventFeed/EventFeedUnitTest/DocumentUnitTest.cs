﻿using AutoFixture;
using EventFeed;
using EventFeed.Models;
using Serilog;
using System.IO;
using EventFeed.Documents;
using Xunit;
using Moq;

namespace EventFeedUnitTest
{
    public class DocumentUnitTest : IClassFixture<EventFixture>
    {
        private readonly EventFixture _eventFixture;

        public DocumentUnitTest(EventFixture eventFixture)
        {
            _eventFixture = eventFixture;
        }

        [Fact] public void Pdf_SaveDefault_OK()
        {
            // Arrange
            var configService = _eventFixture.GetConfigurationService();
            var doc = new DocumentPdf(Mock.Of<ILogger>(), configService);
            var fixture = new Fixture();
            EventInvoice eventInvoice = fixture.Create<EventInvoice>();

            // Act
            doc.Save(eventInvoice);

            // Assert
            Assert.True(File.Exists(Path.Join(configService.InvoiceDirectory, $"{eventInvoice.Content.InvoiceId}.pdf")));

        }
    }
}
