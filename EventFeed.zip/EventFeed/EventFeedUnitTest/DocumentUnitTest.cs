﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoFixture;
using EventFeed;
using EventFeed.Models;
using Xunit;

namespace EventFeedUnitTest
{
    public class DocumentUnitTest
    {
        [Fact] public void Pdf_SaveDefault_OK()
        {
            // Arrange
            var doc = new DocumentPdf();
            var fixture = new Fixture();
            EventItem eventItem = fixture.Create<EventItem>();
            var tempPath = Path.GetTempFileName();
            bool isFileCreated = false;
            
            // Act
            doc.Save(eventItem, tempPath);
            if (File.Exists(tempPath))
            {
                File.Delete(tempPath);
                isFileCreated = true;
            }

            // Assert
            Assert.True(isFileCreated);

        }
    }
}
