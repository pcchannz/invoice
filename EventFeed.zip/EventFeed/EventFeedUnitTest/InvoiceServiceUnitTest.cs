﻿using EventFeed.Models;
using EventFeed.Services;
using Moq;
using Serilog;
using System;
using System.IO;
using System.Linq;
using Xunit;

namespace EventFeedUnitTest
{
    public class InvoiceServiceUnitTest: IClassFixture<EventFixture>

    {
        private readonly EventFixture _eventFixture;

        public InvoiceServiceUnitTest(EventFixture eventFixture)
        {
            _eventFixture = eventFixture;
        }

        [Fact]
        public void Invoice_Save_OK()
        {
            // Arrange
            var response = _eventFixture.Get5EventResponse();
            var mockLogger = new Mock<ILogger>();
            mockLogger.Setup(s => s.ForContext<InvoiceService>()).Returns(Mock.Of<ILogger>());
            var args = new EventArrivedArgs {Response = response};
            var invoiceService = new InvoiceService(mockLogger.Object)
            {
                InvoiceDir = Path.Join(Path.GetTempPath(), new Guid().ToString())
            };
            Directory.CreateDirectory(invoiceService.InvoiceDir);

            // Act
            invoiceService.OnEventArrived(null, args);
            int fileCount = Directory.EnumerateFiles(invoiceService.InvoiceDir).Count();
            Directory.Delete(invoiceService.InvoiceDir, true);

            // Assert
            Assert.True(fileCount > 0);

        }
    }
}
