﻿using EventFeed.Services;
using Moq;
using Serilog;
using System.IO;
using System.Linq;
using Xunit;

namespace EventFeedUnitTest
{
    public class InvoiceServiceUnitTest: IClassFixture<EventFixture>

    {
        private readonly EventFixture _eventFixture;

        public InvoiceServiceUnitTest(EventFixture eventFixture)
        {
            _eventFixture = eventFixture;
        }

        [Fact]
        public void Invoice_Save_OK()
        {
            // Arrange
            var response = _eventFixture.Get5EventResponse();
            var mockLogger = new Mock<ILogger>();
            mockLogger.Setup(s => s.ForContext<InvoiceService>()).Returns(Mock.Of<ILogger>());
            var invoiceService = new InvoiceService(mockLogger.Object, _eventFixture.GetServiceProvider());

            // Act
            invoiceService.OnEventResponse(null, response);


            int fileCount = Directory.EnumerateFiles(_eventFixture.GetConfigurationService().InvoiceDirectory).Count();
            Directory.Delete(_eventFixture.GetConfigurationService().InvoiceDirectory, true);

            // Assert
            Assert.True(fileCount > 0);
        }
    }
}
