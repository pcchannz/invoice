using EventFeed;
using EventFeed.Services;
using Moq;
using Serilog;
using System.Threading;
using System.Threading.Tasks;
using Xunit;


namespace EventFeedUnitTest
{
    public class EventPollServiceUnitTest : IClassFixture<EventFixture>
    {
        private readonly EventFixture _eventFixture;

        public EventPollServiceUnitTest(EventFixture eventFixture)
        {
            _eventFixture = eventFixture;
        }

        [Fact]
        public async Task Polling_IntervalFetching_OK()
        {
            // Arrange
            string responseString = await EventFixture.Get5EventInvoicesAsync();
            int raisedEventCount = 0;
            var cts = new CancellationTokenSource(1000);
            var mockLogger = new Mock<ILogger>();
            mockLogger.Setup(s => s.ForContext<EventPollService>()).Returns(Mock.Of<ILogger>());

            var mockHttpHandler = new Mock<IHttpServices>();
            mockHttpHandler.Setup(s => s.GetStringAsync(It.IsAny<string>(), It.IsAny<CancellationToken>())).ReturnsAsync(responseString);

            var service = new EventPollService(mockLogger.Object, mockHttpHandler.Object, _eventFixture.GetConfigurationService(), Mock.Of<IInvoiceService>());
            service.OnEventResponse += delegate
            {
                raisedEventCount++;
            };

            // Act
            await service.StartPollingAsync(cts.Token);

            // Assert
            Assert.Equal(1, raisedEventCount);
        }

        [Fact]
        public async Task Polling_ContinuousFetching_OK()
        {
            // Arrange
            string responseString = await EventFixture.Get10EventInvoicesAsync();
            int raisedEventCount = 0;
            var cts = new CancellationTokenSource(1000);
            var mockLogger = new Mock<ILogger>();
            mockLogger.Setup(s => s.ForContext<EventPollService>()).Returns(Mock.Of<ILogger>());
            var mockHttpHandler = new Mock<IHttpServices>();
            mockHttpHandler.Setup(s => s.GetStringAsync(It.IsAny<string>(), It.IsAny<CancellationToken>())).ReturnsAsync(responseString);

            var service = new EventPollService(mockLogger.Object, mockHttpHandler.Object, _eventFixture.GetConfigurationService(), Mock.Of<IInvoiceService>());
            service.OnEventResponse += delegate
            {
                raisedEventCount++;
            };

            // Act
            await service.StartPollingAsync(cts.Token);

            // Assert
            Assert.True(raisedEventCount > 1);
        }

        [Fact]
        public async Task Polling_BadResponse_Exception()
        {
            // Arrange
            string responseString = "1";
            var mockLogger = new Mock<ILogger>();
            mockLogger.Setup(s => s.ForContext<EventPollService>()).Returns(Mock.Of<ILogger>());
            var mockHttpHandler = new Mock<IHttpServices>();
            mockHttpHandler.Setup(s => s.GetStringAsync(It.IsAny<string>(), It.IsAny<CancellationToken>())).ReturnsAsync(responseString);
            var service = new EventPollService(mockLogger.Object, mockHttpHandler.Object, _eventFixture.GetConfigurationService(), Mock.Of<IInvoiceService>());
            
            // Act
            var evt = await Record.ExceptionAsync(() => service.StartPollingAsync(new CancellationToken()));

            // Assert
            Assert.NotNull(evt);

        }
    }
}
